/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.Arrays;

import java.util.Arrays;

/**
 *
 * @author wafaalharbi
 */
public class TestArray {
        public static void main(String args[]) {
            int n = 5;
        int[] myArray = new int[n]; 
        myArray[0] = 7;
        myArray[1] = 9;
        myArray[2] = 3;
        myArray[3] = 14;
        myArray[4] = 5;
        
        System.out.println(Arrays.toString(myArray));
        myArray[2] = myArray[2] + 30;
        System.out.println(Arrays.toString(myArray));
        
        System.out.println(myArray.length);
        
        System.out.println("----------- loop using for i-------------------");
            int sum = 0;
        for(int i = 0; i < myArray.length; i++){
              System.out.println(    myArray[i]   );
              sum = sum + myArray[i];
         }
        System.out.println("Sum = "+sum);
        
        System.out.println("----------- loop using for each [ enhanced loop ] -------------------");
            sum = 0; // reset again to 0
        for(int item : myArray){
            System.out.println( item ); 
            sum = sum + item;
        }
           System.out.println("Sum = "+sum);
        }
}
