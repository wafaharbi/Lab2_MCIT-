/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.Arrays;

/**
 *
 * @author wafaalharbi
 */
public class SumArrayEven {
    public static void main(String args []){
        // print sum, count of even numbers
     // print sum, count of odd numbers
     
       int[] myArray = {7, 12, 33, 14, 5}; // array initialize
         double sumEven = 0, sumOdd = 0;
         int countEven = 0, countOdd = 0;
         
       for(int item : myArray){
            if(item % 2 == 0){
                sumEven = sumEven + item;
                countEven++;
            }else{
                sumOdd = sumOdd + item;
                countOdd++;
            }
       }
        
        System.out.println("Sum Even = "+sumEven+", Count Even = "+countEven);
        System.out.println("Sum Odd = "+sumOdd+", Count Odd = "+countOdd);
    }
}
