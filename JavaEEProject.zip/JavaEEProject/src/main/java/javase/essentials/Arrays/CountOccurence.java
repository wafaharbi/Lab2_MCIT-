/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.Arrays;

/**
 *
 * @author wafaalharbi
 */
public class CountOccurence {
    
  public static void main(String args[]){
      
      int[] myArray = {7, 9, 33, 9, 9};
            int number = 9;
            
            int counter = 0;
         for(int item : myArray){
              if(item == number){
                  counter++;
              }
         }
        
         System.out.println("Count Occurence = "+counter);
    }
}
