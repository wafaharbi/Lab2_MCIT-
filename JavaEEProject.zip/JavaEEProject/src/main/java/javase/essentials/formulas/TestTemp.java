/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.formulas;

/**
 *
 * @author wafaalharbi
 */
public class TestTemp {
        public static void main(String args[]){
            
            int tempC=38;
            double tempF = tempC *(9.0/5.0) + 32;
            System.out.println(tempF);
            
        }
}
