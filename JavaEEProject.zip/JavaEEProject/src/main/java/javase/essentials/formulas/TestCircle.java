/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.formulas;

/**
 *
 * @author wafaalharbi
 */
public class TestCircle {
    public static void main(String args[]){
    // inputs 
     // final double PI = 3.145;  // constant 
    
      double radius = 7;
        
      // process = equation = formula
      double area = Math.PI * Math.pow(radius, 2);
         area = Math.round( area * 100  ) / 100.0;
      
      // output 
        System.out.println("Area of circle = "+area);
    }

}
