/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.formulas;

/**
 *
 * @author wafaalharbi
 */
public class TestComplex {
          public static void main(String args[]){
              
            int x = 2, y = 3, a = 4, b = 5, c = 6;
     
        double firstPart = (3 + 4 * x)/ 5.0;
        double secondPart =  10 * ( y - 5 ) * ( a + b + c ) / x;
        double thirdPart = 9 * (4 / x + (9 + x) / y);
        
        double result = firstPart - secondPart + thirdPart;
        System.out.println("Result = "+result);
          }
}
