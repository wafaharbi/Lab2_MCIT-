/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.lab1;

/**
 *
 * @author wafaalharbi
 */
public class Qestion3 {
    
    public static void main(String args[]){

       int i = 2;
       int num1 = 1+i;
       int num2 = 1-i;
       double power3= Math.pow(num1,3);
       double power5= Math.pow(num2,5);
       double result = power3 /power5;
       System.out.println("The result = "+ result);

           
       }
}
