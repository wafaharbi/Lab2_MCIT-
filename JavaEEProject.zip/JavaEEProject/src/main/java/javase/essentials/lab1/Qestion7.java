/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.lab1;

/**
 *
 * @author wafaalharbi
 */
public class Qestion7 {
 public static void main(String args[]){

    double loenAmount =100000.0;
    double mounthly_Interst_Rate =0.01;
    int No_of_Years = 7;
    
    double mounthlyPayment , totalPayment;
    
    
    double plus = 1+mounthly_Interst_Rate;
    double powerMulti = No_of_Years *12;
    double power =Math.pow(plus, powerMulti);
    
    mounthlyPayment =(((loenAmount*mounthly_Interst_Rate))/1)/(1-(1/power));
    double mounthlyPaymentRound = Math.round( mounthlyPayment * 100  ) / 100.0;

    totalPayment = mounthlyPayment * No_of_Years * 12;
    double totalPaymentRound = Math.round( totalPayment * 100  ) / 100.0;

    System.out.println(" The mounthlyPayment  "+ mounthlyPaymentRound);
    System.out.println(" The totalPayment "+  totalPaymentRound);

 }    
}
