/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.basics;

/**
 *
 * @author wafaalharbi
 */
public class TestAverage {
    
   public static void main(String args[]){
       
       // sout ctrl + space
       System.out.println("welocome to java");
       
       // declare variables
       int num1 =4;
       int num2 =6;
       int num3 =9;
       
       double average = (num1+ num2 + num3)/3.0;
       System.out.println("Average =" + average);
       
       
   }
}
