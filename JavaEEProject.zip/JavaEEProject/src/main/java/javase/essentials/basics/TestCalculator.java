/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.basics;

/**
 *
 * @author wafaalharbi
 */
public class TestCalculator {
    // psvm ctrl + space
    
      public static void main(String args[]){
          
          int num1 =4;
          int num2 =6;
          
          int addResult = num1 + num2;
          int subResult = num1 - num2;
          int multiResult = num1 * num2;
         
          // Casting : convert from int to double
          double divdResult = (double)num1 / num2;
          
          System.out.println("Add = " + addResult);
          System.out.println("Substrac = " + subResult);
          System.out.println("Multiply = " + multiResult);
          System.out.println("Divide = " + divdResult);

          //  incremnt
          num1 ++;
          num1 = num1 +1;
          num1 +=1;
          //++ num1;
          System.out.println("num1 " + num1);

          
          // decrement
          num1--;
          num1 = num1 - 1;
          num1 -= 1;
          //-- num1;
          System.out.println("num1 " + num1);

          // power
         double sqrtNum = Math.pow(2, 4);
         System.out.println("Power" + sqrtNum);
         
         // Square root
         double srnum = Math.sqrt(16);
         System.out.println("Square root " + srnum);
         
         // round
        double invoiceTotal = 4350.678231;
        System.out.println(Math.round(invoiceTotal * 10)/10.0); //4350.7
        System.out.println(Math.round(invoiceTotal * 100)/100.0); //4350.68
        System.out.println(Math.round(invoiceTotal * 1000)/1000.0); //4350.678
        System.out.println(Math.round(invoiceTotal)); //4351
       
        
        // Casting 
        // Convert from int to doule :from smaller to larger
        int deptCode = 50;
        double dept = deptCode + 2.7;
        System.out.println(dept);
        
       // Convert from double to int : from larger to smaller
      double empSalary =5000.66;
      int emSal = (int)empSalary;
      System.out.println(emSal);
      
      // Mod
      System.out.println(6 /2);
      System.out.println(6 %2);
      System.out.println(11 %3);
      System.out.println(37 %3);
      System.out.println(443 %6);
      System.out.println(98659 %10);
  
      // even & odd numbers
      System.out.println(6 /2); //0 then even
      System.out.println(7 /2); // 1 then odd
      
      // total seconds = 140 seconds  = ? minutes | seconds
           int totalSeconds = 140;
           int minutes = totalSeconds / 60;
          System.out.println("minutes = "+minutes); 
          int remainingSeconds = totalSeconds % 60;
          System.out.println("Remaining = "+remainingSeconds);
           System.out.println("------------------------");
            int bottles = 712;
            int boxCapacity = 11;
            
            int filledBoxes = bottles / boxCapacity;
            System.out.println("Filled boxes = "+filledBoxes);
               int remainingBottles = bottles % boxCapacity;
               System.out.println("Remaining bottles = "+remainingBottles);


   }
}
