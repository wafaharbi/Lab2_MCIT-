/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.lab2;

import java.util.Scanner;

/**
 *
 * @author wafaalharbi
 */
public class SumAverageInputs {
    
            public static void main(String args[]) {
                
             Scanner input = new Scanner(System.in);
             int sum =0;
             double average = 0;
             for(int i=0; i<5; i++){
                 System.out.println("Please enter numbers: ");
                int usrNum = input.nextInt();
                sum = sum + usrNum;
                average = sum /usrNum;         

             }
             System.out.println("The average = "+ average);
             System.out.println("Sum = "+sum);                
                
                
            }
}
