/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.lab2;

import java.util.Scanner;

/**
 *
 * @author wafaalharbi
 */
public class SumAverageInputsArrays {
      public static void main(String args[]){
          
          
       System.out.println("Please Enter number of elements in your array:");
          
        int numberOfElemnt, sum = 0;
        double average = 0;
        Scanner input = new Scanner(System.in);
        numberOfElemnt = input.nextInt();
        int array[] = new int[numberOfElemnt];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < numberOfElemnt; i++)
        {
            array[i] = input.nextInt();
            sum = sum + array[i];
            average = sum /array[i];
        }
        System.out.println("Sum = "+sum + "  ,  Average = "+ average);
    }
        
        }
      

