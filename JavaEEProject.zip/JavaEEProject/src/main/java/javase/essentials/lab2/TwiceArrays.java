/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.lab2;

/**
 *
 * @author wafaalharbi
 */
public class TwiceArrays {

    public static void main(String args[]) {

        int array1[] = {4, 5, 20, 3};
        int array2[] = new int[4];

        for (int i = 0; i < array1.length; i++) {
            int resultArray = array1[i] * 2;
            array2[i] = resultArray;
        }
        for (int item : array2) {
            System.out.print(" " + item);
        }
    }
}       
        
  
