/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.lab2;

import java.util.Scanner;

/**
 *
 * @author wafaalharbi
 */
public class PositiveNegativeNumsArrays {
    public static void main(String args []){
        
        
     System.out.println("Please Enter number of elements in your array:");
          
        int numberOfElemnt, sum = 0;
        double average = 0;
        int positveNum =0,negativeNum =0, positive_numbersCount =0 , negative_numbersCount =0;
        int zero_count=0;
             
        Scanner input = new Scanner(System.in);
        numberOfElemnt = input.nextInt();
        int array[] = new int[numberOfElemnt];
        
        System.out.println("Enter all the elements:");
        for(int i = 0; i < numberOfElemnt; i++)
        {
            array[i] = input.nextInt();
            if(array[i] >= 1){
               positveNum =positveNum + array[i];
               positive_numbersCount++;
            }
            else if(array[i] < 0){
                  negativeNum = negativeNum + array[i];
               negative_numbersCount++;  
                }
            else {
               zero_count ++;

            }
           
        }
             System.out.println("Sum = "+positveNum + "   Count Positve = "+ positive_numbersCount);
             System.out.println("Sum = "+negativeNum + "   Count Negative = "+ negative_numbersCount);
             System.out.println(" Count of Zero = "+ zero_count);
    }
    
}

