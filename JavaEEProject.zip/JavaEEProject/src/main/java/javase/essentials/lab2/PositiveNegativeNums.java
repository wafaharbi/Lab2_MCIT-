/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.lab2;

import java.util.Scanner;

/**
 *
 * @author wafaalharbi
 */
public class PositiveNegativeNums {
       public static void main(String args[]) {
                         
              Scanner input = new Scanner(System.in);
             int positveNum =0,negativeNum =0, positive_numbersCount =0 , negative_numbersCount =0;
             int zero_count=0;
             for(int i=0; i<5; i++){
                 System.out.println("Please enter numbers: ");
             
                int usrNum = input.nextInt();
                if(usrNum >= 1){
               positveNum =positveNum + usrNum;
               positive_numbersCount++;
                }else if(usrNum < 0){
                  negativeNum = negativeNum + usrNum;
               negative_numbersCount++;  
                }
                else{
                  
                    zero_count ++;
                }
             }
             System.out.println("Sum = "+positveNum + "  Count Positve = "+ positive_numbersCount);
             System.out.println("Sum = "+negativeNum + "  Count Negative = "+ negative_numbersCount);
             System.out.println(" Count of Zero = "+ zero_count);
         }
}
