/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.loops;

/**
 *
 * @author wafaalharbi
 */
public class TestSumNumbers {
        public static void main(String args[]) {
            
            // Calculate sum numbers 1 to 100
            int sum = 0;
            for(int i=1; i<101 ;i++){
                sum = sum+i; // معادلة تراكمية
            }
            System.out.println(sum);
            double average = sum /100.0;
           System.out.println(average);

        }
}
