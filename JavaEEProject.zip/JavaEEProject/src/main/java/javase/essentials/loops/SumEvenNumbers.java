/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.loops;

import java.util.Scanner;

/**
 *
 * @author wafaalharbi
 */
public class SumEvenNumbers {
         public static void main(String args[]) {
             
             //print sum even numbers enterd by user 
             
              Scanner input = new Scanner(System.in);
             int sumEven =0,sumOdd =0, evenNum =0 , oddNum =0;
             for(int i=0; i<5; i++){
                 System.out.println("Please enter numbers: ");
             
                int usrNum = input.nextInt();
                if(usrNum %2 == 0){
               sumEven = sumEven + usrNum;
               evenNum++;
                }else{
                  sumOdd = sumOdd + usrNum;
               oddNum++;  
                }
             }
             System.out.println("Sum = "+sumEven + "Count Even "+ evenNum);
             System.out.println("Sum = "+sumOdd + "Count Even "+ oddNum);

         }
}
