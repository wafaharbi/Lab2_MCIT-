/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.loops;

import java.util.Scanner;

/**
 *
 * @author wafaalharbi
 */
public class TestMAxMin {
             public static void main(String args[]) {
                 
                 // get the max numbers enterd by users
                 
                   Scanner input = new Scanner(System.in);
                   int max =0, min =0;
         
             for(int i=0; i<5; i++){
                 System.out.println("Please enter numbers: ");
                 int usrNum = input.nextInt();
                 
                 if(i == 0){
                     max = usrNum;
                     min = usrNum;
                 }
                 if(usrNum > max){
                     max = usrNum;
                 }
                  if(usrNum < min){
                     min = usrNum;
                 }
             }
        
             System.out.println("Max = "+max);
             System.out.println("Min = "+min);

             }
             
}
