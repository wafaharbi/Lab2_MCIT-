/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.loops;

/**
 *
 * @author wafaalharbi
 */
public class TestLoop {
     public static void main(String args[]) {
         
         // Program that print numbers from 1 to 100
        //Using for loops
         for(int i =1; i<101; i++){
             System.out.print("  "+i);
         }
         System.out.println("");
         
        //Using while loops
        int i= 1;
        while(i<101){
        System.out.print("  "+i);
        i++;


     }
         System.out.println("");
          i=1;
         do{
            
         System.out.print("  "+i);
        i++;
         }while(i<101);

     }   
}
