/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.conditions;

/**
 *
 * @author wafaalharbi
 */
public class OrderDiscount {
     public static void main(String args[]){
         double itemCost = 200.0; 
         int itemQty = 3;
         int specialClient = 0; // 1 = special   |   0 > not special 
         int discountPct = 0; 
         double discountVal = 0.0;
         
         double totalOrderCost = itemCost * itemQty;
         
         if( totalOrderCost >= 1000){
               // nested if condition
              if(specialClient == 1){
                   discountPct = 20;
              }else if(specialClient == 0){
                   discountPct = 10;
              }  
         }
         discountVal = totalOrderCost * discountPct / 100.0;
         System.out.println("Total Order Cost Before Discount = "+totalOrderCost);
         totalOrderCost = totalOrderCost - discountVal;
         System.out.println("Total Order Cost After Discount = "+totalOrderCost);
                 
         System.out.println("Discount Pct = "+discountPct);
         System.out.println("Discount Val = "+discountVal);
     }
}
