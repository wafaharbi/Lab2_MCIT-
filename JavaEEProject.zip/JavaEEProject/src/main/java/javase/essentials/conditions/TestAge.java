/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.conditions;

/**
 *
 * @author wafaalharbi
 */
public class TestAge {
    public static void main(String args []){
        
     String personName = "Ahmed";
     int personAge = 10;   
        
     if(personAge > 16)
     {
         System.out.println("You are a man");
     } 
     else if(personAge >= 11 && personAge <= 16)
     {
         System.out.println("You are a boy");
     }
     else{
         System.out.println("You are a child");
     }
     
     
     
    }
}
