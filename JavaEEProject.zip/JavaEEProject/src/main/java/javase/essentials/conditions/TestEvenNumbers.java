/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.conditions;

/**
 *
 * @author wafaalharbi
 */
public class TestEvenNumbers {
         public static void main(String args[]){
             
             int number = 5;
             
             if(number % 2 == 0){
                 System.out.println(" number is even");
             }
             else{
             System.out.println(" number is odd");

             }
         }
}
