/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.conditions;

import java.util.Scanner;

/**
 *
 * @author wafaalharbi
 */
public class RandomGame {
        public static void main(String args []){
            
        Scanner input = new Scanner(System.in);
        int correctAnswers = 0 , wrongAnswer =0;
        
        while(true){
        int num1 = (int) (Math.random() *100);
        int num2 = (int) (Math.random() *100);;
        
        //Random
        //System.out.println((int)(Math.random() *100));
        System.out.println(" Enter -1 to Stop the game");
        System.out.println(num1 + " + " +num2 + " = ");
              int result = input.nextInt();
        if(result == -1){
            break;
        }
        if ( result == (num1 + num2)){
            System.out.println("Correct answer");
            correctAnswers ++;
        }
        else{
        System.out.println("wrong answer");
         wrongAnswer ++;
        }
        
        }
        System.out.println("Numbers of correct answer = "+ correctAnswers +
                " &&  Numbers of wrong answer = "+ wrongAnswer);
        }
}
