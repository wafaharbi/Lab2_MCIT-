/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.conditions;

import java.util.Date;

/**
 *
 * @author wafaalharbi
 */
public class TestEmpTax {
    public static void main(String args []){
        
        //inputs
        int empId = 101;
        String empName = "Ahmed";
        double empGrossSalary = 7000.0;  // salary before removing tax
        String empJop = "Java Devolper";
        boolean isRetried = true;
        char empGender ='M';
        Date empHiredDate = new Date();
        int tax =10;
        
        // processes
        // salary after removing tax = 6300.0  10%
        double empMounthlyNetSalary =  empGrossSalary - empGrossSalary * tax /100.0;
        double empAnnualNetSalary = empMounthlyNetSalary * 12; 
        
        System.out.println("Employee Net Salary = " + empMounthlyNetSalary);
        System.out.println("Employee Annual Net Salary = " + empAnnualNetSalary);
        System.out.println("Employee ID is "+ empId +
                           " named is "+ empName +
                           ", is retired? " + isRetried);
        System.out.println("employee Gender is " + empGender +
                " hired on "+ empHiredDate );
    }
}
