/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.essentials.conditions;

/**
 *
 * @author wafaalharbi
 */
public class TestSwitch {

    public static void main(String args[]) {

        char gradeApprve = 'A';
        String grade;

        switch (gradeApprve) {
            case 'A':
                grade = "Exellent";
                break;
            case 'B':
                grade = "Very good";
                break;
            case 'C':
                grade = "good";
                break;
            default:
                grade = "Very good";
        }

        System.out.println("Grade = " + grade);
    }

}
